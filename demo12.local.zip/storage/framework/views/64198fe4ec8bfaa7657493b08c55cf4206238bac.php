<div class="card uper search-form">
    <div class="card-header">Search Filter</div>
    <div class="card-body">
        <form method="get" action="<?php echo e(route('transactions.index')); ?>/">
            <div class="row">
                <div class='col-sm-3'>
                    <div class="form-group">
                        <label for="date_from">From:</label>
                        <div class='input-group date'>
                            <input type='text' class="form-control" name="date_from" value="<?php echo e(\Request::get('date_from')); ?>"/>
                            <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span>
                    </span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class='col-sm-3'>
                    <div class="form-group">
                        <label for="date_to">To:</label>
                        <div class='input-group date'>
                            <input type='text' class="form-control" name="date_to" value="<?php echo e(\Request::get('date_to')); ?>"/>
                            <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span>
                    </span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class='col-sm-3'>
                    <div class="form-group">
                        <label for="user_id">Users:</label>
                        <select class="form-control" name="user_id">
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(\Request::get('user_id') == $user->id): ?>
                                    <option value="<?php echo e($user->id); ?>" selected><?php echo e($user->name); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Search</button>
        </form>
    </div>
</div>
<?php /**PATH E:\xampp\htdocs\demo12.local\resources\views/transactions/_search.blade.php ENDPATH**/ ?>