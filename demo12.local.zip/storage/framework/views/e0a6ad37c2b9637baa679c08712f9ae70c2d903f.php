<?php $__env->startSection('content'); ?>
<style>
  .uper {
    margin-top: 40px;
  }
</style>
<div class="card uper">
  <div class="card-header">Edit User</div>
  <div class="card-body">
    <?php if($errors->any()): ?>
      <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div><br />
    <?php endif; ?>
      <form method="post" action="<?php echo e(route('users.update', $user->id)); ?>">
        <?php echo method_field('PATCH'); ?>
        <?php echo csrf_field(); ?>
        <div class="form-group">
          <label for="name">Name:</label>
          <input type="text" class="form-control" name="name" value="<?php echo e($user->name); ?>" />
        </div>
        <div class="form-group">
          <label for="email">Email:</label>
          <input type="password" class="form-control" name="email" value="<?php echo e($user->email); ?>" />
        </div>
          <div class="form-group">
              <label for="password">Password:</label>
              <input type="text" class="form-control" name="password" value="" />
          </div>
          <div class="form-group">
              <label for="role">Role:</label>
              <select class="form-control" name="role">
                  <option value="2">User</option>
                  <option value="1">Admin</option>
              </select>
          </div>
          <div class="form-group">
              <label for="role">Currencies:</label>
              <select class="form-control" name="currency_code">
                  <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($user->wallet()->first()->currency_id == $currency->id): ?>
                          <option value="<?php echo e($currency->code); ?>" selected><?php echo e($currency->code); ?></option>
                      <?php else: ?>
                          <option value="<?php echo e($currency->code); ?>"><?php echo e($currency->code); ?></option>
                      <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
          </div>
        <button type="submit" class="btn btn-primary">Update</button>
      </form>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\demo12.local\resources\views/users/edit.blade.php ENDPATH**/ ?>