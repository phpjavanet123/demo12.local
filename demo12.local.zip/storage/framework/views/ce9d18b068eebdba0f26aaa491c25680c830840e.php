<?php $__env->startSection('content'); ?>
<div class="uper">
  <?php echo $__env->make('transactions._search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div class="card-header">Transactions
          <div class="export-to-files">
              <a href="<?php echo e($exportFileUrl->xmlUrl); ?>"><img title="Export to XML" src="/images/xml.png" /></a>
              <a href="<?php echo e($exportFileUrl->csvUrl); ?>"><img title="Export to CSV" src="/images/csv.png" /></a>
          </div>
      </div>
  <table class="table table-striped thead-dark">
    <thead>
        <tr>
          <td>Transaction ID</td>
          <td>Status</td>
		  <td>Amount</td>
		  <td>Source Wallet</td>
          <td>Destination Wallet</td>
          <td>Executed Date</td>
        </tr>
    </thead>
    <tbody>
		<?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($transaction->id); ?></td>
            <td><?php echo e($transaction->status); ?></td>
            <td>$<?php echo e($transaction->default_currency_amount); ?></td>
            <td><?php echo e($transaction->from_wallet_currency_amount); ?> in wallet currency</td>
            <td><?php echo e($transaction->to_wallet_currency_amount); ?> in wallet currency</td>
            <td><?php echo e($transaction->executed_at); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr style="font-weight: bold">
            <td colspan="2" style="text-align: right;">Total:</td>
            <td><?php echo e($transactionsDefaultSum); ?></td>
            <td><?php echo e($transactionsSum); ?></td>
            <td></td>
            <td></td>
        </tr>
    </tbody>
  </table>
<div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\demo11.local\resources\views/transactions/index.blade.php ENDPATH**/ ?>